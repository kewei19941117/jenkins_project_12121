class TestLogin:

    def test_login1(self):
        assert 1

    def test_login2(self):
        assert 0

    def test_login3(self):
        assert 1

    def test_login4(self):
        assert 1
